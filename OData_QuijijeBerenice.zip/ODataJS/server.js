const express = require("express");
const app = express();
const port = 3000;

const productos = [
    { Id: 1, Nombre: "Laptop", Precio: 1500, Categoria: "Electrónica" },
    { Id: 2, Nombre: "Mouse", Precio: 25, Categoria: "Accesorios" },
    { Id: 3, Nombre: "Teclado", Precio: 45, Categoria: "Accesorios" }
];

// Ruta principal
app.get("/odata/Productos", (req, res) => {
    let data = [...productos];

    // $filter
    if (req.query.$filter) {
        const filter = req.query.$filter;
        const match = filter.match(/(\w+)\s+eq\s+'([^']+)'/);
        if (match) {
            const [, field, value] = match;
            data = data.filter(item => item[field] == value);
        }
    }

    // $select
    if (req.query.$select) {
        const fields = req.query.$select.split(",");
        data = data.map(item => {
            const obj = {};
            fields.forEach(f => obj[f] = item[f]);
            return obj;
        });
    }

    // $orderby
    if (req.query.$orderby) {
        const [field, direction] = req.query.$orderby.split(" ");
        data.sort((a, b) => {
            if (direction === "desc") return b[field] - a[field];
            return a[field] - b[field];
        });
    }

    res.json(data);
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}/odata/Productos`);
});
