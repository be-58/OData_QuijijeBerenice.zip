require("reflect-metadata");
const { ODataController, Edm } = require("odata-v4-server");
const Producto = require("../entities/Producto");

const productos = [
    { Id: 1, Nombre: "Laptop", Precio: 1500, Categoria: "Electrónica" },
    { Id: 2, Nombre: "Mouse", Precio: 25, Categoria: "Accesorios" },
    { Id: 3, Nombre: "Teclado", Precio: 45, Categoria: "Accesorios" }
];

class ProductoController extends ODataController {
    @Edm.GET
    async get() {
        return productos;
    }
}

module.exports = ProductoController;
