const { Edm } = require("odata-v4-server");

class Producto {
    @Edm.Key
    @Edm.Int32
    Id;

    @Edm.String
    Nombre;

    @Edm.Double
    Precio;

    @Edm.String
    Categoria;
}

module.exports = Producto;

